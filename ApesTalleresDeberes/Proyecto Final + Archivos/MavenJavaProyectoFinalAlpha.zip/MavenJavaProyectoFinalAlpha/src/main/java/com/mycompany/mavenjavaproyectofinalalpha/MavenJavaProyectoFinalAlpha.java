/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.mavenjavaproyectofinalalpha;

import LOGICAFINAL.Pantalla;

/**
 *
 * @author Sebas
 */
public class MavenJavaProyectoFinalAlpha {

    public static void main(String[] args) {
        Pantalla ejecutable = new Pantalla();
        ejecutable.setVisible(true);
        ejecutable.setLocationRelativeTo(null);
    }
}
