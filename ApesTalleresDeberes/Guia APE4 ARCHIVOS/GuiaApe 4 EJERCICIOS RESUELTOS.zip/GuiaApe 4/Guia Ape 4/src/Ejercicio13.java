
import java.util.Scanner;

public class Ejercicio13 {
    public static void LeerImprimir() {
        Scanner teclado = new Scanner(System.in);
        double[] tempMin = new double[5];
        double[] tempMax = new double[5];
        double[] TemperaturaMedia = new double[5];
System.out.println("========== Ingreso de DATOS de temperaturas ==========");
        System.out.println("Ingrese la temperatura mínima y máxima de 5 días:");
        for (int i = 0; i < 5; i++) {
            System.out.print("Día " + (i + 1) + " - Temperatura Mínima: ");
            tempMin[i] = teclado.nextDouble();
            System.out.print("Día " + (i + 1) + " - Temperatura Máxima: ");
            tempMax[i] = teclado.nextDouble();
            TemperaturaMedia[i] = (tempMin[i] + tempMax[i]) / 2;
        }

        int diaMin = obtenerIndiceMinimo(TemperaturaMedia);
        int diaMax = obtenerIndiceMaximo(TemperaturaMedia);

        System.out.println("Temperatura media de cada día:");
        for (int i = 0; i < 5; i++) {
            System.out.println("Día " + (i + 1) + ": " + TemperaturaMedia[i] + "°C");
        }

        System.out.println("El día con la temperatura promedio más baja es:  Día " + (diaMin + 1) 
                + " "+TemperaturaMedia[diaMin] + "°C");
        System.out.println("El día con la temperatura promedio más alta es:  Día " + (diaMax + 1) 
                + " "+TemperaturaMedia[diaMax] + "°C");

    }

    public static int obtenerIndiceMinimo(double[] array) {
        int IndoceMinimo = 0;
        for (int i = 1; i < array.length; i++) {
            if (array[i] < array[IndoceMinimo]) {
                IndoceMinimo = i;
            }
        }
        return IndoceMinimo;
    }

    public static int obtenerIndiceMaximo(double[] array) {
        int IndiceMaximo = 0;
        for (int i = 1; i < array.length; i++) {
            if (array[i] > array[IndiceMaximo]) {
                IndiceMaximo = i;
            }
        }
        return IndiceMaximo;
    }

    public static void main(String[] args) {
        LeerImprimir();
    }

}
