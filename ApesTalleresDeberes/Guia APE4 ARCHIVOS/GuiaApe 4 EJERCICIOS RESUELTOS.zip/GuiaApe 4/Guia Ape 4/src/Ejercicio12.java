import java.util.ArrayList;
import java.util.Scanner;

public class Ejercicio12 {
    public static void LeerImprimir() {
    Scanner teclado = new Scanner(System.in);
        ArrayList<String> nombres = new ArrayList<>();
        ArrayList<Integer> edades = new ArrayList<>();

        System.out.println("Ingrese el nombre y la edad de los alumnos (Ingrese '*' para finalizar):");

        while (true) {
            System.out.print("Nombre: ");
            String nombre = teclado.nextLine();
            if (nombre.equals("*"))
                break;

            System.out.print("Edad: ");
            int edad = teclado.nextInt();
            teclado.nextLine();

            nombres.add(nombre);
            edades.add(edad);
        }

        mostrarMayoresDeEdad(nombres, edades);

}
public static void mostrarMayoresDeEdad(ArrayList<String> nombres, ArrayList<Integer> edades) {
        System.out.println("Los Alumnos mayores de edad son:");
        for (int i = 0; i < edades.size(); i++) {
            if (edades.get(i) >= 18) {
                System.out.println(nombres.get(i) + " - " + edades.get(i) + " años");
            }
        }
    }
    public static void main(String[] args) {
        LeerImprimir();
    }
}
