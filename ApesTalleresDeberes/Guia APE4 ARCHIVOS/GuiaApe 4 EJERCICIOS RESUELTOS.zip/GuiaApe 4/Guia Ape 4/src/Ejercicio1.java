import java.util.Scanner;

//1. Dado 4 números, almacénelos en un vector; luego obtenga la suma y el promedio de los valores 
//almacenados. 

public class Ejercicio1 {

    public static void LecturaImpresion() {
        Scanner teclado = new Scanner(System.in);
        int[] Vector = new int[4];
        System.out.println("============ Lectura de datos ===========");
        System.out.print("Ingresa el valor de un Numero: ");
        Vector[0] = teclado.nextInt();
        System.out.print("Ingresa el valor de un Numero: ");
        Vector[1] = teclado.nextInt();
        System.out.print("Ingresa el valor de un Numero: ");
        Vector[2] = teclado.nextInt();
        System.out.print("Ingresa el valor de un Numero: ");
        Vector[3] = teclado.nextInt();

        System.out.println("La sumatoria de tus numeros es: " + SumatoriaVector(Vector));
        System.out.println("El promedio de tus numeros es: " + PromedioVector(SumatoriaVector(Vector)));

    }

    public static int SumatoriaVector(int[] Vector) {
        int Sumatoria = 0;
        for (int i = 0; i < Vector.length; i++) {
            Sumatoria += Vector[i];
        }
        return Sumatoria;

    }

    public static double PromedioVector(int Sumatoria_) {
        double Promedio = (Sumatoria_) / 4.0;
        return Promedio;
    }

    public static void main(String[] args) {
        LecturaImpresion();
    }

}
