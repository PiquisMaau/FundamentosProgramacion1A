import java.util.Scanner;

public class Ejercicio2 {
    // 2. Dado 6 números, almacénelos en un vector; luego obtenga cuántos números
    // múltiplos de n hay ingresado.

    public static void LecturaImpresion() {

    }

    public static void LeerImprimir() {
        Scanner teclado = new Scanner(System.in);
        System.out.println("========== Ingresa 6 Numeros ==========");
        int[] Vector = new int[6];
        for (int i = 0; i < Vector.length; i++) {
            System.out.print("Ingresa el valor de un número: ");
            Vector[i] = teclado.nextInt();
        }
        System.out.print("Ingresa el valor de un número para determinar si tiene multiplos: ");
        int NumeroMultiplo = teclado.nextInt();

        System.out.println("La cantidad de multiplis para el numero: " + NumeroMultiplo + " es: "
                + contarMultiplos(Vector, NumeroMultiplo));
    }

    public static int contarMultiplos(int[] Vector_, int numroMult) {
        int contador = 0;
        for (int ValorVector : Vector_) {
            if (ValorVector % numroMult == 0) {
                contador++;
            }
        }
        return contador;

    }

    public static void main(String[] args) {
        LeerImprimir();
    }

}
