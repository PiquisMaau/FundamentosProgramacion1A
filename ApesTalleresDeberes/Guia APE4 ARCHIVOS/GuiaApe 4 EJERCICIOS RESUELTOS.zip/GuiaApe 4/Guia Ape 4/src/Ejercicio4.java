import java.util.HashMap;
import java.util.Scanner;

public class Ejercicio4 {

    public static void LecturaeImpresion() {
        Scanner teclado = new Scanner(System.in);
        System.out.println("========== Ingresa 6 Números ==========");
        int[] Vector = new int[6];
        for (int i = 0; i < Vector.length; i++) {
            System.out.print("Ingresa el valor de un número: ");
            Vector[i] = teclado.nextInt();
        }
        NumerosRepetidos(Vector);

    }
    public static void NumerosRepetidos(int[] Vector_){
        HashMap<Integer, Integer> Repetidos = new HashMap<>();

        for (int ValorCel : Vector_) {
            Repetidos.put(ValorCel, Repetidos.getOrDefault(ValorCel, 0) + 1);
        }

        System.out.println("Números repetidos:");
        for (int ValorCelda : Repetidos.keySet()) {
            if (Repetidos.get(ValorCelda) > 1) {
                System.out.println(ValorCelda + " se repite " + Repetidos.get(ValorCelda) + " veces.");
            }


    }

}
public static void main(String[] args) {
    LecturaeImpresion();
}
}
