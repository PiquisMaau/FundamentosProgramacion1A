import java.util.Arrays;
import java.util.Random;

public class Ejercicio9 {
    /*
     * 9. Hacer un programa que inicialice un vector de números con valores
     * aleatorios, y posterior ordene los
     * elementos de menor a mayor.
     */

    public static void main(String[] args) {
        int[] numeros = new int[5];
        Random random = new Random();

        for (int i = 0; i < numeros.length; i++) {
            numeros[i] = random.nextInt(99) + 1;
        }

        System.out.println("Vector inicial: " + Arrays.toString(numeros));

        Arrays.sort(numeros);

        System.out.println("Vector ordenado de Menor  a Mayor: " + Arrays.toString(numeros));
    }
}
