import java.util.Arrays;
import java.util.Scanner;

public class Ejercicio10 {
    /*
     * 10. Programa que declare tres vectores ‘vector1’, ‘vector2’ y ‘vector3’ de
     * cinco enteros cada uno, pida valores
     * para ‘vector1’ y ‘vector2’ y calcule vector3=vector1+vector2.
     */
    public static void LecturaeImpresion() {
        Scanner teclado = new Scanner(System.in);
        int[] Vector1 = new int[5];
        int[] Vector2 = new int[5];
        System.out.println("============ Ingreso de DATOS en el Vector 1 ===========");
        for (int i = 0; i < Vector1.length; i++) {
            System.out.print("Ingresa los valores del vector 1 en la posición: " + (i + 1) + ": ");
            Vector1[i] = teclado.nextInt();
        }
        for (int i = 0; i < Vector2.length; i++) {
            System.out.print("Ingresa los valores del vector 2 en la posición: " + (i + 1) + ": ");
            Vector2[i] = teclado.nextInt();
        }

        System.out.println("El vector 3 es: " + Arrays.toString(SumaVECTORES(Vector1, Vector2)));
    }

    public static int[] SumaVECTORES(int[] Vector1_, int[] Vector2_) {

        int[] Vector3 = new int[5];
        for (int i = 0; i < Vector3.length; i++) {
            Vector3[i] = Vector1_[i] + Vector2_[i];
        }
        return Vector3;
    }

    public static void main(String[] args) {
        LecturaeImpresion();
    }
}
