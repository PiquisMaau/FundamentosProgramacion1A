import java.util.Scanner;

public class Ejercicio7 {
    /*
     * 7. Crear un vector de 5 elementos de cadenas de caracteres, inicializa el
     * vector con datos leídos por el
     * teclado. Copia los elementos del vector en otro vector, pero en orden
     * inverso, y muéstralo por la pantalla.
     */

    public static void LeerImprimir() {
        Scanner teclado = new Scanner(System.in);
        String[] vectorOriginal = new String[5];
        String[] vectorInverso = new String[5];

        System.out.println("Ingresa 5 cadenas de texto: ");
        for (int i = 0; i < vectorOriginal.length; i++) {
            System.out.print("Elemento " + (i + 1) + ": ");
            vectorOriginal[i] = teclado.nextLine();
        }

        for (int i = 0; i < vectorOriginal.length; i++) {
            vectorInverso[i] = vectorOriginal[vectorOriginal.length - 1 - i];
        }

        System.out.println("Tu vector en orden inverso es:");
        for (String elemento : vectorInverso) {
            System.out.println(elemento);
        }

    }

    public static void main(String[] args) {
        LeerImprimir();
    }
}
