import java.util.ArrayList;
import java.util.Scanner;

public class Ejercicio11 {
    /*
     * Guardar los nombres y las edades de los alumnos de un curso. Realiza un
     * programa que introduzca el
     * nombre y la edad de cada alumno. El proceso de lectura de datos terminará
     * cuando se introduzca como
     * nombre un asterisco (*). Al finalizar se mostrará los siguientes datos:
     * • Todos los alumnos mayores de edad.
     * • El promedio de los alumnos menores de Edad
     */

    public static void LeerImprimir() {
        Scanner teclado = new Scanner(System.in);
        ArrayList<String> nombres = new ArrayList<>();
        ArrayList<Integer> edades = new ArrayList<>();

        System.out.println("Ingrese el nombre y la edad de los alumnos (Ingrese '*' para finalizar):");

        while (true) {
            System.out.print("Nombre: ");
            String nombre = teclado.nextLine();
            if (nombre.equals("*"))
                break;

            System.out.print("Edad: ");
            int edad = teclado.nextInt();
            teclado.nextLine();

            nombres.add(nombre);
            edades.add(edad);
        }

        mostrarMayoresDeEdad(nombres, edades);
        PromedioMenores(edades);
    }

    public static void mostrarMayoresDeEdad(ArrayList<String> nombres, ArrayList<Integer> edades) {
        System.out.println("Los Alumnos mayores de edad son:");
        for (int i = 0; i < edades.size(); i++) {
            if (edades.get(i) >= 18) {
                System.out.println(nombres.get(i) + " - " + edades.get(i) + " años");
            }
        }
    }

    public static void PromedioMenores(ArrayList<Integer> edades) {
        int suma = 0, contador = 0;
        for (int edad : edades) {
            if (edad < 18) {
                suma += edad;
                contador++;
            }
        }
        if (contador > 0) {
            System.out.println("Promedio de edad de los alumnos menores: " + (double) suma / contador);
        } else {
            System.out.println("No hay alumnos menores de edad.");
        }
    }

    public static void main(String[] args) {

        LeerImprimir();
    }
}
