import java.util.Arrays;
import java.util.Scanner;

public class Ejercicio6 {
    /*
     * 6. Se tiene un array Coches de ocho elementos de contiene seis marcas de
     * automóviles en orden alfabético
     * y se desea insertar dos nuevas marcas: Opel y Citroen. Programe un algoritmo
     * que permita introducir las
     * nuevas marcas en el
     */

    public static void LeerImprimir() {
        Scanner teclado = new Scanner(System.in);
        System.out.println("========== Lista de COCHES ==========");
        System.out.println("Ingresa más marcas de coches que necesites en la lista: ");
        String opel = teclado.next();
        String citroen = teclado.next();

        String[] ListaCoches = { "Alfa Romeo", "Fiat", "Ford", "Lancia", "Renault", "Seat", opel, citroen };

        System.out.println(Arrays.toString(ListaCoches));

    }

    public static void main(String[] args) {
        LeerImprimir();
    }

}
