import java.util.Arrays;
import java.util.Scanner;

public class Ejercicio5 {
    /*
     * 5. Dado como entrada un numero n, encuentre los primeros 10 números primos
     * subsecuentes, almacénelos en un array cada valor encontrado, imprímalos y
     * calcule: suma y
     * promedio de los primos encontrados.
     * 
     */

    public static void LeerImprimir() {
        Scanner teclado = new Scanner(System.in);
        System.out.println("=========== Lectura de DATOS ========== ");
        System.out.println("Ingresa un numero para comenzar: ");
        int numero = teclado.nextInt();
        int[] primos = SacarPrimos(numero, 10);

        System.out.println("Los primeros 10 primos después de " + numero + " son: " + Arrays.toString(primos));

        System.out.println("La Sumatoria de los números primos encntrados es: " + calcularSuma(primos));
        System.out.println("El Promedio de los primos encontrados es: " + calcularPromedio(primos));
    }

    public static boolean DeterminarPrimo(int num) {
        if (num < 2)
            return false;
        for (int i = 2; i <= Math.sqrt(num); i++) {
            if (num % i == 0)
                return false;
        }
        return true;
    }

    public static int[] SacarPrimos(int n, int cantidad) {
        int[] primos = new int[cantidad];
        int contador = 0;
        int numero = n + 1;

        while (contador < cantidad) {
            if (DeterminarPrimo(numero)) {
                primos[contador] = numero;
                contador++;
            }
            numero++;
        }
        return primos;
    }

    public static int calcularSuma(int[] numeros) {
        int suma = 0;
        for (int num : numeros) {
            suma += num;
        }
        return suma;
    }

    public static double calcularPromedio(int[] numeros) {
        return (double) calcularSuma(numeros) / numeros.length;
    }

    public static void main(String[] args) {
        LeerImprimir();
    }

}
