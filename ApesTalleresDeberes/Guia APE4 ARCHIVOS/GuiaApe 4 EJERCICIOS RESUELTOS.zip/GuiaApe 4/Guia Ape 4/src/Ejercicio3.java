import java.util.Arrays;
import java.util.Scanner;

public class Ejercicio3 {

    // 3. Ordene 5 números según la forma que se indique: A (ascendente) o D
    // (descendente).

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        int[] numeros = new int[5];

        System.out.println("========= Lectura de DATOS ===========");
        System.out.println("Ingrese 5 números:");
        for (int i = 0; i < numeros.length; i++) {
            System.out.print("Número " + (i + 1) + ": ");
            numeros[i] = teclado.nextInt();
        }

        System.out.print("Ingrese 'A' para orden ascendente o 'D' para orden descendente: ");
        char orden = teclado.next().toUpperCase().charAt(0);

        ordenarVector(numeros, orden);

        System.out.println("Números ordenados: " + Arrays.toString(numeros));

    }

    public static void ordenarVector(int[] numeros, char orden) {
        Arrays.sort(numeros);

        if (orden == 'D') {
            for (int i = 0; i < numeros.length / 2; i++) {
                int temp = numeros[i];
                numeros[i] = numeros[numeros.length - 1 - i];
                numeros[numeros.length - 1 - i] = temp;
            }
        }
    }
}
