import java.util.Scanner;
import java.util.Arrays;

public class Ejercicio8 {
    /*
     * 8. Se quiere realizar un programa que lea por teclado las 5 notas obtenidas
     * por un alumno (comprendidas
     * entre 0 y 10). A continuación, debe mostrar todas las notas, la nota media,
     * la nota más alta que ha sacado
     * y la menor.
     */

    public static void LeerImprimir() {
        Scanner teclado = new Scanner(System.in);
        double[] notas = new double[5];

        System.out.println("Ingrese 5 notas (entre 0 y 10):");
        for (int i = 0; i < notas.length; i++) {
            do {
                System.out.print("Nota " + (i + 1) + ": ");
                notas[i] = teclado.nextDouble();
            } while (notas[i] < 0 || notas[i] > 10); // Validación de rango
        }

        double promedio = PromedioAlumnos(notas);
        double notaMaxima = MaximoNota(notas);
        double notaMinima = NotaMinima(notas);

        System.out.println("Notas ingresadas: " + Arrays.toString(notas));
        System.out.println("Nota media: " + promedio);
        System.out.println("Nota más alta: " + notaMaxima);
        System.out.println("Nota más baja: " + notaMinima);
    }

    public static double PromedioAlumnos(double[] notas) {
        double Sumatoria = 0;
        for (double nota : notas) {
            Sumatoria += nota;
        }
        return Sumatoria / notas.length;
    }

    public static double MaximoNota(double[] notas) {
        double NotaMaxima = notas[0];
        for (double nota : notas) {
            if (nota > NotaMaxima) {
                NotaMaxima = nota;
            }
        }
        return NotaMaxima;
    }

    public static double NotaMinima(double[] notas) {
        double NMinima = notas[0];
        for (double nota : notas) {
            if (nota < NMinima) {
                NMinima = nota;
            }
        }
        return NMinima;
    }

    public static void main(String[] args) {
        LeerImprimir();
    }
}
